# Flatiron School Data Science Take-Home Assignment

This is the take-home project for the DS Curriculum Writer position at Flatiron School.

- **Step 1**: Create a clone of this repository, resulting in a repo https://github.com/YourUserName/ds-take-home-project

- **Step 2**: Create a new branch named `edits` in your forked repository, pull this branch locally, and make changes to the Jupyter Notebook

- **Step 3**: Once you're done editing, commit and push your results, and create a pull request between your `edits` branch and the master branch **of your forked repository**, and send the link of the pull request to your Flatiron School recruiter (link will be something like this: 
https://github.com/YourUserName/ds-take-home-project/pull/1)

Good luck!!
